﻿namespace PersonalFiles.DAL
{
    public class PersonPosition
    {
        public int Id { get; set; }

        public int PersonId { get; set; }

        public int PositionId { get; set; }
    }
}
