﻿namespace PersonalFiles.DAL
{
    public interface IInsurancePolicyRepository : IRepository<InsurancePolicy>
    {
    }
}
