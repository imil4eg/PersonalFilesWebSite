﻿namespace PersonalFiles.DAL
{
    public interface IEducationRepository : IRepository<Education>
    {
    }
}
