﻿namespace PersonalFiles.DAL
{
    public interface IPersonPositionRepository : IRepository<PersonPosition>
    {
    }
}
