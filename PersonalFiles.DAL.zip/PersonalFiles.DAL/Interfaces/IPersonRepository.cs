﻿namespace PersonalFiles.DAL
{
    public interface IPersonRepository : IRepository<Person>
    {
    }
}
