﻿namespace PersonalFiles.DAL
{
    public interface IPassportRepository : IRepository<Passport>
    {
    }
}
