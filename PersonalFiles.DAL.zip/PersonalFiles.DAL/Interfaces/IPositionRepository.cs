﻿namespace PersonalFiles.DAL
{
    public interface IPositionRepository : IRepository<Position>
    {
    }
}
