﻿namespace PersonalFiles.DAL
{
    public interface IUserRepository : IRepository<ApplicationUser> 
    {
    }
}
